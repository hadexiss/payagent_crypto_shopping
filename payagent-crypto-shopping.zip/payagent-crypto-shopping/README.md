# PayAgent — Autonomous Crypto AI Shopping Agent

PayAgent is an interactive Web3 AI shopping interface powered by **ERC-4337 Account Abstraction Session Keys**, cross-chain liquidity routing (`Li.Fi`, `Jupiter v6`, `CoW Swap`), and autonomous price-sniping execution.

## Features
- **ERC-4337 Smart Session Key Manager**: Set daily USDC spending caps, reset allowances, or pause autonomous signing without exposing raw private keys.
- **Multi-Chain Intent Switcher**: Seamlessly toggle between **Base**, **Solana**, **Arbitrum**, and **Ethereum** with zero-gas Paymaster sponsorship.
- **Conversational AI Product Discovery**: Search across Web2 (Amazon JIT Virtual Cards, Newegg) and Web3 (Solana Pay, Bitrefill) rails.
- **Live 4-Step Autonomous Execution Pipeline**: Real-time simulation of session verification, DEX routing, merchant settlement, and on-chain receipt minting.
- **Autonomous Price Snipers**: Set target prices and trigger simulated instant executions.

## Quick Start (Local Development)

```bash
npm install
npm run dev
```

## Push to GitHub

```bash
git init
git add .
git commit -m "Initial commit: PayAgent Crypto AI Shopping Agent"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo-name>.git
git push -u origin main
```
