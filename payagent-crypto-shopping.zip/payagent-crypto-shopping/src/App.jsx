import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Wallet,
  Sparkles,
  Zap,
  Search,
  CheckCircle2,
  ArrowRight,
  Sliders,
  Crosshair,
  Receipt,
  RefreshCw,
  ExternalLink,
  Plus,
  Trash2,
  Lock,
  Unlock,
  AlertCircle,
  Cpu,
  Globe,
  ShoppingCart
} from 'lucide-react';

const CHAINS = [
  { id: 'base', name: 'Base', token: 'USDC', balance: 1420.50, router: 'Li.Fi Cross-Chain', badge: 'bg-blue-500/20 text-blue-400 border-blue-500/30' },
  { id: 'solana', name: 'Solana', token: 'USDC', balance: 890.00, router: 'Jupiter v6', badge: 'bg-purple-500/20 text-purple-400 border-purple-500/30' },
  { id: 'arbitrum', name: 'Arbitrum', token: 'USDC', balance: 640.25, router: 'CoW Swap Intent', badge: 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30' },
  { id: 'ethereum', name: 'Ethereum', token: 'USDC', balance: 3110.00, router: 'UniswapX', badge: 'bg-slate-500/20 text-slate-300 border-slate-500/30' }
];

const INITIAL_PRODUCTS = [
  {
    id: 'prod-1',
    name: 'Sony WH-1000XM5 Wireless Noise Canceling Headphones',
    category: 'Audio & Tech',
    price: 298.00,
    originalPrice: 399.99,
    merchant: 'Amazon via JIT Virtual Card',
    rail: 'Zero-Gas ERC-4337 Paymaster',
    rating: '4.9 ★ (12.4k)',
    delivery: '2-Day Prime Shipping',
    inStock: true,
    tags: ['Best Price', 'Price Drop']
  },
  {
    id: 'prod-2',
    name: 'Ledger Nano X — Bluetooth Crypto Hardware Wallet',
    category: 'Web3 Hardware',
    price: 149.00,
    originalPrice: 149.00,
    merchant: 'Solana Pay Direct',
    rail: 'Atomic USDC Settlement',
    rating: '4.8 ★ (5.1k)',
    delivery: 'Express Global Courier',
    inStock: true,
    tags: ['Crypto Native', 'Cashback 2%']
  },
  {
    id: 'prod-3',
    name: 'Kingston NV2 1TB M.2 2280 NVMe Internal SSD',
    category: 'PC Components',
    price: 58.50,
    originalPrice: 69.99,
    merchant: 'Newegg Crypto Checkout',
    rail: 'Li.Fi Bridge + Settlement',
    rating: '4.8 ★ (8.9k)',
    delivery: '3-5 Business Days',
    inStock: true,
    tags: ['High Speed', 'Low Latency']
  },
  {
    id: 'prod-4',
    name: '$100 Steam Wallet Digital Gift Code (Global)',
    category: 'Gaming & Digital',
    price: 96.00,
    originalPrice: 100.00,
    merchant: 'Bitrefill Atomic Swap',
    rail: 'Instant Lightning / L2 Delivery',
    rating: '5.0 ★ (29.2k)',
    delivery: 'Instant On-Screen Code',
    inStock: true,
    tags: ['4% Instant Discount', 'Instant']
  }
];

const INITIAL_SNIPERS = [
  {
    id: 'snipe-1',
    item: 'PlayStation 5 Pro Console (Digital Edition)',
    targetPrice: 620.00,
    currentPrice: 699.99,
    merchant: 'BestBuy / Amazon Auto-Route',
    status: 'Monitoring'
  },
  {
    id: 'snipe-2',
    item: 'Apple AirPods Pro (2nd Gen, USB-C)',
    targetPrice: 179.00,
    currentPrice: 189.99,
    merchant: 'Walmart / Target JIT Card',
    status: 'Monitoring'
  }
];

export default function App() {
  const [selectedChain, setSelectedChain] = useState(CHAINS[0]);
  const [allowanceCap, setAllowanceCap] = useState(500);
  const [allowanceUsed, setAllowanceUsed] = useState(250);
  const [sessionActive, setSessionActive] = useState(true);
  const [showAllowanceModal, setShowAllowanceModal] = useState(false);

  const [searchQuery, setSearchQuery] = useState('');
  const [chatHistory, setChatHistory] = useState([
    {
      sender: 'agent',
      text: 'Session key active (`0x71C...89A`). I can search Web2 & Web3 merchants, swap tokens cross-chain with zero gas, and execute checkouts within your spending allowance.'
    }
  ]);

  const [products, setProducts] = useState(INITIAL_PRODUCTS);
  const [activeExecution, setActiveExecution] = useState(null);
  const [executionStep, setExecutionStep] = useState(0);
  const [receipts, setReceipts] = useState([]);

  const [snipers, setSnipers] = useState(INITIAL_SNIPERS);
  const [newSnipeItem, setNewSnipeItem] = useState('');
  const [newSnipePrice, setNewSnipePrice] = useState('');

  const remainingAllowance = Math.max(0, allowanceCap - allowanceUsed);

  const handlePromptSubmit = (e) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    const query = searchQuery.trim();
    setChatHistory((prev) => [...prev, { sender: 'user', text: query }]);
    setSearchQuery('');

    setTimeout(() => {
      const filtered = INITIAL_PRODUCTS.filter(
        (p) =>
          p.name.toLowerCase().includes(query.toLowerCase()) ||
          p.category.toLowerCase().includes(query.toLowerCase()) ||
          p.tags.some((t) => t.toLowerCase().includes(query.toLowerCase()))
      );

      if (filtered.length > 0) {
        setProducts(filtered);
        setChatHistory((prev) => [
          ...prev,
          {
            sender: 'agent',
            text: `Found ${filtered.length} matching item(s) across verified settlement rails. Ready for 1-click autonomous checkout on ${selectedChain.name}.`
          }
        ]);
      } else {
        setProducts(INITIAL_PRODUCTS);
        setChatHistory((prev) => [
          ...prev,
          {
            sender: 'agent',
            text: `I scanned global merchant APIs for "${query}" and routed the best rates. Showing top verified items ready for ${selectedChain.name} settlement.`
          }
        ]);
      }
    }, 350);
  };

  const triggerAgentBuy = (product, isSnipe = false) => {
    if (!sessionActive) {
      alert('Session Key is paused! Enable autonomous execution in the Session Key modal first.');
      return;
    }
    if (product.price > remainingAllowance) {
      setShowAllowanceModal(true);
      return;
    }

    setActiveExecution({
      product,
      isSnipe,
      chain: selectedChain,
      txHash: '0x' + Math.random().toString(16).substring(2, 10) + '...' + Math.random().toString(16).substring(2, 6)
    });
    setExecutionStep(1);
  };

  useEffect(() => {
    if (!activeExecution || executionStep === 0) return;

    if (executionStep < 4) {
      const timer = setTimeout(() => {
        setExecutionStep((prev) => prev + 1);
      }, 950);
      return () => clearTimeout(timer);
    } else if (executionStep === 4) {
      setAllowanceUsed((prev) => +(prev + activeExecution.product.price).toFixed(2));
      setReceipts((prev) => [
        {
          id: 'rcpt-' + Date.now(),
          item: activeExecution.product.name,
          amount: activeExecution.product.price,
          chain: activeExecution.chain.name,
          rail: activeExecution.product.merchant,
          txHash: activeExecution.txHash,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
        },
        ...prev
      ]);
    }
  }, [activeExecution, executionStep]);

  const handleAddSniper = (e) => {
    e.preventDefault();
    if (!newSnipeItem.trim() || !newSnipePrice) return;
    const priceNum = parseFloat(newSnipePrice);
    if (isNaN(priceNum) || priceNum <= 0) return;

    const newRule = {
      id: 'snipe-' + Date.now(),
      item: newSnipeItem.trim(),
      targetPrice: priceNum,
      currentPrice: +(priceNum * 1.15).toFixed(2),
      merchant: 'Multi-Merchant Auto-Router',
      status: 'Monitoring'
    };

    setSnipers((prev) => [newRule, ...prev]);
    setNewSnipeItem('');
    setNewSnipePrice('');
  };

  const simulateSnipeHit = (snipe) => {
    setSnipers((prev) =>
      prev.map((s) => (s.id === snipe.id ? { ...s, currentPrice: s.targetPrice, status: 'Executed' } : s))
    );
    triggerAgentBuy(
      {
        id: snipe.id,
        name: snipe.item,
        price: snipe.targetPrice,
        merchant: snipe.merchant,
        rail: 'Autonomous Price Sniper Trigger'
      },
      true
    );
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Navbar */}
      <header className="border-b border-slate-800/80 bg-slate-900/60 backdrop-blur-md sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5 flex flex-wrap items-center justify-between gap-4">
          {/* Brand */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-400 to-cyan-500 flex items-center justify-center shadow-lg shadow-emerald-500/20">
              <Zap className="w-5 h-5 text-slate-950 fill-slate-950" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-lg tracking-tight text-white">PayAgent</span>
                <span className="text-[11px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                  ERC-4337 Smart Session
                </span>
              </div>
              <p className="text-xs text-slate-400">Autonomous Crypto AI Shopping & Settlement</p>
            </div>
          </div>

          {/* Right Controls */}
          <div className="flex flex-wrap items-center gap-3">
            {/* Session Key Allowance Pill */}
            <button
              onClick={() => setShowAllowanceModal(true)}
              className="flex items-center gap-3 px-3.5 py-2 rounded-xl bg-slate-800/90 hover:bg-slate-800 border border-slate-700/80 transition text-left"
            >
              <div className="flex items-center gap-1.5">
                {sessionActive ? (
                  <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                ) : (
                  <Lock className="w-4 h-4 text-amber-400 shrink-0" />
                )}
                <div>
                  <div className="text-[11px] text-slate-400 flex items-center gap-1">
                    <span>Session Allowance</span>
                    <Sliders className="w-3 h-3 text-slate-400" />
                  </div>
                  <div className="text-xs font-semibold text-white">
                    ${remainingAllowance.toFixed(2)} <span className="text-slate-400 font-normal">/ ${allowanceCap} USDC left</span>
                  </div>
                </div>
              </div>
              <div className="w-16 h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-700">
                <div
                  className={`h-full transition-all ${
                    remainingAllowance < 75 ? 'bg-amber-400' : 'bg-emerald-400'
                  }`}
                  style={{ width: `${Math.min(100, (remainingAllowance / allowanceCap) * 100)}%` }}
                />
              </div>
            </button>

            {/* Chain Selector */}
            <div className="flex items-center bg-slate-900 border border-slate-800 rounded-xl p-1">
              {CHAINS.map((chain) => (
                <button
                  key={chain.id}
                  onClick={() => setSelectedChain(chain)}
                  className={`px-2.5 py-1.5 rounded-lg text-xs font-medium transition ${
                    selectedChain.id === chain.id
                      ? 'bg-slate-800 text-white shadow-sm border border-slate-700'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {chain.name}
                </button>
              ))}
            </div>

            {/* Smart Wallet Pill */}
            <div className="flex items-center gap-2.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs">
              <Wallet className="w-4 h-4 text-cyan-400" />
              <div>
                <div className="font-mono text-slate-200">0x71C...89A</div>
                <div className="text-[11px] text-emerald-400 font-medium">
                  {selectedChain.balance.toLocaleString()} {selectedChain.token}
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Conversational Discovery + Product Grid */}
        <div className="lg:col-span-7 flex flex-col gap-6">
          {/* AI Agent Prompt Console */}
          <div className="bg-slate-900/70 border border-slate-800/90 rounded-2xl p-5 shadow-xl">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <h2 className="text-sm font-semibold text-white">Agent Discovery & Intent Router</h2>
              </div>
              <span className={`text-xs px-2.5 py-0.5 rounded-full border ${selectedChain.badge}`}>
                Router: {selectedChain.router}
              </span>
            </div>

            {/* Chat Feed */}
            <div className="space-y-2.5 mb-4 max-h-40 overflow-y-auto pr-1">
              {chatHistory.map((msg, i) => (
                <div
                  key={i}
                  className={`text-xs leading-relaxed px-3.5 py-2.5 rounded-xl ${
                    msg.sender === 'user'
                      ? 'bg-emerald-500/15 text-emerald-200 border border-emerald-500/30 ml-8'
                      : 'bg-slate-950/90 text-slate-300 border border-slate-800 mr-4'
                  }`}
                >
                  <span className="font-semibold uppercase text-[10px] tracking-wider block mb-0.5 opacity-70">
                    {msg.sender === 'user' ? 'You' : 'PayAgent AI'}
                  </span>
                  {msg.text}
                </div>
              ))}
            </div>

            {/* Search Input */}
            <form onSubmit={handlePromptSubmit} className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Ask PayAgent to find products, compare prices, or buy with USDC..."
                className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500/60 rounded-xl pl-10 pr-28 py-3 text-sm text-white placeholder-slate-500 focus:outline-none"
              />
              <button
                type="submit"
                className="absolute right-2 top-1/2 -translate-y-1/2 px-3.5 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold text-xs transition flex items-center gap-1"
              >
                <span>Route</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </form>

            {/* Quick Suggestion Chips */}
            <div className="flex flex-wrap items-center gap-2 mt-3">
              <span className="text-[11px] text-slate-400">Try:</span>
              {['Sony Headphones', 'Hardware Wallet', 'NVMe SSD', 'Steam Gift Card', 'Show All'].map((chip) => (
                <button
                  key={chip}
                  onClick={() => {
                    if (chip === 'Show All') {
                      setProducts(INITIAL_PRODUCTS);
                    } else {
                      setSearchQuery(chip);
                    }
                  }}
                  className="text-xs px-2.5 py-1 rounded-lg bg-slate-800/80 hover:bg-slate-800 text-slate-300 border border-slate-700/70 transition"
                >
                  {chip}
                </button>
              ))}
            </div>
          </div>

          {/* Curated Product Cards */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
                <ShoppingCart className="w-4 h-4 text-cyan-400" />
                <span>Verified Merchant Inventory ({products.length})</span>
              </h3>
              <span className="text-xs text-slate-400">Zero-gas ERC-4337 Sponsored</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {products.map((product) => (
                <div
                  key={product.id}
                  className="bg-slate-900/70 border border-slate-800/90 hover:border-slate-700 rounded-2xl p-4 flex flex-col justify-between transition group"
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <span className="text-[11px] font-medium px-2 py-0.5 rounded-md bg-slate-800 text-slate-300">
                        {product.category}
                      </span>
                      <span className="text-xs text-amber-400 font-medium">{product.rating}</span>
                    </div>

                    <h4 className="font-semibold text-sm text-white group-hover:text-emerald-300 transition line-clamp-2 mb-2">
                      {product.name}
                    </h4>

                    <div className="space-y-1 text-xs text-slate-400 mb-4">
                      <div className="flex items-center gap-1.5">
                        <Globe className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                        <span className="truncate">{product.merchant}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Cpu className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span className="truncate">{product.rail}</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between gap-2">
                    <div>
                      <div className="text-lg font-bold text-white">${product.price.toFixed(2)}</div>
                      <div className="text-[11px] text-slate-400">
                        {product.price} {selectedChain.token} on {selectedChain.name}
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          setNewSnipeItem(product.name);
                          setNewSnipePrice((product.price * 0.9).toFixed(0));
                        }}
                        title="Create Price Sniper"
                        className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition"
                      >
                        <Crosshair className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => triggerAgentBuy(product)}
                        className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 font-semibold text-xs transition shadow-md shadow-emerald-500/10 flex items-center gap-1.5"
                      >
                        <Zap className="w-3.5 h-3.5 fill-slate-950" />
                        <span>1-Click Buy</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Live Execution Pipeline + Price Snipers + On-Chain Receipts */}
        <div className="lg:col-span-5 flex flex-col gap-6">
          {/* Live Autonomous Checkout Stepper */}
          <div className="bg-slate-900/70 border border-slate-800/90 rounded-2xl p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Cpu className="w-4 h-4 text-cyan-400" />
                <h3 className="text-sm font-semibold text-white">Live Agent Execution Pipeline</h3>
              </div>
              {activeExecution && (
                <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                  {executionStep < 4 ? 'Executing On-Chain...' : 'Settled'}
                </span>
              )}
            </div>

            {!activeExecution ? (
              <div className="text-center py-8 px-4 border border-dashed border-slate-800 rounded-xl">
                <Zap className="w-7 h-7 text-slate-600 mx-auto mb-2" />
                <p className="text-xs text-slate-400">
                  Click <span className="text-slate-200 font-semibold">1-Click Buy</span> on any product or trigger a{' '}
                  <span className="text-slate-200 font-semibold">Price Sniper</span> to watch the autonomous ERC-4337 settlement pipeline.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <div className="truncate pr-2">
                    <div className="text-xs font-semibold text-white truncate">{activeExecution.product.name}</div>
                    <div className="text-[11px] text-slate-400">
                      {activeExecution.product.merchant} • {activeExecution.chain.name}
                    </div>
                  </div>
                  <div className="text-sm font-bold text-emerald-400 shrink-0">
                    ${activeExecution.product.price.toFixed(2)} USDC
                  </div>
                </div>

                {[
                  {
                    step: 1,
                    title: 'Verify ERC-4337 Session Key & Spend Cap',
                    desc: `Confirmed allowance <= $${allowanceCap} USDC without raw private key exposure`
                  },
                  {
                    step: 2,
                    title: `Optimal Route via ${activeExecution.chain.router}`,
                    desc: `Zero-slippage atomic settlement on ${activeExecution.chain.name} (Paymaster Gas: $0.00)`
                  },
                  {
                    step: 3,
                    title: 'Merchant Payment & Order Fulfillment',
                    desc: `Settled via ${activeExecution.product.merchant}`
                  },
                  {
                    step: 4,
                    title: 'Cryptographic Receipt Minted',
                    desc: `Tx Hash: ${activeExecution.txHash}`
                  }
                ].map((item) => {
                  const isDone = executionStep >= item.step;
                  const isCurrent = executionStep === item.step && executionStep < 4;
                  return (
                    <div
                      key={item.step}
                      className={`p-3 rounded-xl border transition flex items-start gap-3 ${
                        isDone
                          ? 'bg-emerald-500/10 border-emerald-500/30 text-slate-100'
                          : 'bg-slate-950/50 border-slate-800/80 text-slate-500'
                      }`}
                    >
                      <div className="mt-0.5">
                        {isCurrent ? (
                          <RefreshCw className="w-4 h-4 text-emerald-400 animate-spin" />
                        ) : isDone ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        ) : (
                          <div className="w-4 h-4 rounded-full border border-slate-700" />
                        )}
                      </div>
                      <div className="text-xs">
                        <div className="font-semibold">{item.title}</div>
                        <div className="text-[11px] opacity-80 mt-0.5">{item.desc}</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Autonomous Price Snipers */}
          <div className="bg-slate-900/70 border border-slate-800/90 rounded-2xl p-5">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Crosshair className="w-4 h-4 text-purple-400" />
                <h3 className="text-sm font-semibold text-white">Autonomous Price Snipers</h3>
              </div>
              <span className="text-[11px] text-slate-400">24/7 On-Chain Watcher</span>
            </div>

            <form onSubmit={handleAddSniper} className="grid grid-cols-1 sm:grid-cols-12 gap-2 mb-4">
              <input
                type="text"
                placeholder="Product name to monitor..."
                value={newSnipeItem}
                onChange={(e) => setNewSnipeItem(e.target.value)}
                className="sm:col-span-7 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500/60"
              />
              <input
                type="number"
                placeholder="Target $"
                value={newSnipePrice}
                onChange={(e) => setNewSnipePrice(e.target.value)}
                className="sm:col-span-3 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500/60"
              />
              <button
                type="submit"
                className="sm:col-span-2 bg-purple-500 hover:bg-purple-400 text-slate-950 font-semibold rounded-xl py-2 text-xs flex items-center justify-center transition"
              >
                <Plus className="w-4 h-4" />
              </button>
            </form>

            <div className="space-y-2.5">
              {snipers.map((snipe) => (
                <div
                  key={snipe.id}
                  className="p-3 rounded-xl bg-slate-950 border border-slate-800/90 flex items-center justify-between gap-2"
                >
                  <div className="min-w-0">
                    <div className="text-xs font-semibold text-white truncate">{snipe.item}</div>
                    <div className="text-[11px] text-slate-400 mt-0.5">
                      Target: <span className="text-emerald-400 font-semibold">${snipe.targetPrice}</span> • Now: $
                      {snipe.currentPrice}
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    {snipe.status === 'Monitoring' ? (
                      <button
                        onClick={() => simulateSnipeHit(snipe)}
                        className="px-2.5 py-1.5 rounded-lg bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 border border-purple-500/30 text-[11px] font-medium transition"
                      >
                        Simulate Target Hit
                      </button>
                    ) : (
                      <span className="px-2.5 py-1 rounded-lg bg-emerald-500/15 text-emerald-400 text-[11px] font-medium">
                        Executed ✓
                      </span>
                    )}
                    <button
                      onClick={() => setSnipers((prev) => prev.filter((s) => s.id !== snipe.id))}
                      className="p-1.5 text-slate-500 hover:text-rose-400 transition"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Verifiable Cryptographic Receipts */}
          {receipts.length > 0 && (
            <div className="bg-slate-900/70 border border-slate-800/90 rounded-2xl p-5">
              <div className="flex items-center gap-2 mb-3">
                <Receipt className="w-4 h-4 text-emerald-400" />
                <h3 className="text-sm font-semibold text-white">On-Chain Order Receipts</h3>
              </div>
              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {receipts.map((r) => (
                  <div
                    key={r.id}
                    className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs flex items-center justify-between"
                  >
                    <div className="truncate pr-2">
                      <div className="font-medium text-slate-200 truncate">{r.item}</div>
                      <div className="text-[11px] text-slate-400 font-mono">
                        {r.chain} • {r.txHash} • {r.timestamp}
                      </div>
                    </div>
                    <div className="text-emerald-400 font-bold shrink-0">-${r.amount.toFixed(2)}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Session Key Permissions Modal */}
      {showAllowanceModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
                <h3 className="font-bold text-base text-white">ERC-4337 Session Key Guardrails</h3>
              </div>
              <button
                onClick={() => setShowAllowanceModal(false)}
                className="text-xs text-slate-400 hover:text-white"
              >
                Close
              </button>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed mb-5">
              Grant time-bound, spend-capped permissions to PayAgent. Your master private key never leaves your hardware wallet.
            </p>

            <div className="space-y-4 mb-6">
              <div>
                <div className="flex justify-between text-xs mb-1.5">
                  <span className="text-slate-300">Daily Spend Allowance Cap</span>
                  <span className="font-bold text-emerald-400">${allowanceCap} USDC</span>
                </div>
                <input
                  type="range"
                  min="100"
                  max="2500"
                  step="50"
                  value={allowanceCap}
                  onChange={(e) => setAllowanceCap(Number(e.target.value))}
                  className="w-full accent-emerald-400"
                />
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800">
                <div>
                  <div className="text-xs font-semibold text-white">Autonomous Execution Status</div>
                  <div className="text-[11px] text-slate-400">
                    {sessionActive ? 'Agent can sign transactions within cap' : 'All autonomous signing paused'}
                  </div>
                </div>
                <button
                  onClick={() => setSessionActive(!sessionActive)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition ${
                    sessionActive
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                  }`}
                >
                  {sessionActive ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
                  <span>{sessionActive ? 'Active' : 'Paused'}</span>
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between gap-3">
              <button
                onClick={() => setAllowanceUsed(0)}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 transition"
              >
                Reset Used ($0)
              </button>
              <button
                onClick={() => setShowAllowanceModal(false)}
                className="flex-1 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold text-xs transition"
              >
                Save Smart Session Policy
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
